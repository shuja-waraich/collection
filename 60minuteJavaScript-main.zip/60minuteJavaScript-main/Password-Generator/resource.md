## CheatSheet Reference

[ASCII](https://www.petefreitag.com/cheatsheets/ascii-codes/)
